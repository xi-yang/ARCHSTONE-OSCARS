if(!dojo._hasResource["tests.fx"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["tests.fx"] = true;
dojo.provide("tests.fx");
if(dojo.isBrowser){
	doh.registerUrl("tests.fx", dojo.moduleUrl("tests", "fx.html"), 30000);
	doh.registerUrl("tests.NodeList-fx", dojo.moduleUrl("tests", "NodeList-fx.html"));
}

}
